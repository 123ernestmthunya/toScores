﻿using App;

string fileName = "TestData.csv";

Console.WriteLine(AppDomain.CurrentDomain.BaseDirectory);

string filePath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, fileName);

var candidates = CsvReader.GetCandidates(filePath);


List<Candidate> topCandidates = candidates.Where(s => s.Score >= 78).ToList();


foreach (var candidate in topCandidates)
{
    Console.WriteLine($"{candidate.FirstName} {candidate.LastName}");
    Console.WriteLine($"Score : {candidate.Score}");
}

