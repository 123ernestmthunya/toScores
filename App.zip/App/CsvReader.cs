﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace App
{
    public static class CsvReader
    {
        // No need to use async since the file only contains 4 entries
        public static List<Candidate> GetCandidates(string filePath)
        {
            var candates = new List<Candidate>();

            try
            {
                using (StreamReader reader = new StreamReader(filePath))
                {
                    string line;

                    while ((line = reader.ReadLine()) != null)
                    {
                        string[] data = line.Split(',');

                        if (data[0] != "First Name" && data[1] != "Second Name" && data[2] != "Score")
                        {
                            candates.Add(new Candidate
                            {
                                FirstName = data[0],
                                LastName = data[1],
                                Score = int.Parse(data[2])

                            });
                        }

                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error reading CSV file: {ex.Message}");
            }

            return candates;
        }

    }
}
